//SOCKET EVENTS

var socket = io.connect(window.location.origin);

//Whenever the server emits 'new-spot', push this new spot onto the array
socket.on('new-spot', function (data) {
  spots.push(data);
});

//Whenever the server emits all-spots put allspots array into data array
socket.on('all-spots', function(allspots) {
  for (var i = 0; i < allspots.length; i ++) {
//****************************************************************************
//**** SAM! What cant i push the spots from allspots array onto the existing spots array?? *********
//************************************************
    var data = allspots[i];
    spots.push(data[i]);
    console.log(data);
  }
});


var spots = [];
var myColor;

function setup() {
  colorMode(HSB);
  createCanvas(800, 800);
  //make a random color.
  myColor = random(255);


}

function draw() {
  background(0);

  //run through spots array
  for (var i = 0; i < spots.length; i++){
    //display each spot.
    spots[i].display();
  }

  println("length:"+spots.length);
}

function makeSpot(){
  //if pressed add new ellipse
  var newSpot = new Spot(30, mouseX, mouseY, myColor);
  spots.push(newSpot);
  println("spot!");
  socket.emit('new-spot', {spot: newSpot});  //*******************SAM can i do this???? does this send an spot obejct?
}

function mousePressed() {
  //set color to random color
  makeSpot();
}


function mouseDragged() {
  //set color to random color
  makeSpot();
}

//*************** This is a different way to write a class in javascript *************
function Spot(size, x, y, color) { //it has 3 arguments size, x and y
  this.size = size;
  this.x = x;
  this.y = y;
  this.color=color;

}

//and a function called 'make' which draws it
Spot.prototype.display = function() {
  fill(this.color, 255, 255);
  ellipse(this.x,this.y,this.size,this.size);

}
